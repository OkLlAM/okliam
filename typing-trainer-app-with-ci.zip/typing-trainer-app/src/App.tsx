import { Card, CardContent, CardHeader, CardTitle } from './components/ui/card'
import { Button } from './components/ui/button'
import { Slider } from './components/ui/slider'
import { Switch } from './components/ui/switch'
import { Badge } from './components/ui/badge'
import { Input } from './components/ui/input'
import { Label } from './components/ui/label'

function App() {
  return (
    <div className="min-h-screen flex items-center justify-center p-6">
      <Card className="max-w-md w-full">
        <CardHeader>
          <CardTitle>Typing Trainer</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <Label>Enter Text</Label>
            <Input placeholder="Type here..." />
            <Slider value={[50]} min={0} max={100} onValueChange={() => {}} />
            <Switch checked={true} onCheckedChange={() => {}} />
            <Badge>Beginner</Badge>
            <Button>Start</Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

export default App