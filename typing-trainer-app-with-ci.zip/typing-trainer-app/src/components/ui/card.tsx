export function Card({ children, className }: { children: React.ReactNode, className?: string }) {
  return <div className={`rounded-2xl shadow p-4 bg-white ${className}`}>{children}</div>
}
export function CardHeader({ children }: { children: React.ReactNode }) {
  return <div className="mb-2">{children}</div>
}
export function CardTitle({ children }: { children: React.ReactNode }) {
  return <h2 className="text-xl font-bold">{children}</h2>
}
export function CardContent({ children }: { children: React.ReactNode }) {
  return <div>{children}</div>
}