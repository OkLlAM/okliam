export function Slider({ value, min, max, onValueChange }: { value: number[], min: number, max: number, onValueChange: (val: number[]) => void }) {
  return <input type="range" min={min} max={max} value={value[0]} onChange={(e) => onValueChange([+e.target.value])} className="w-full" />
}